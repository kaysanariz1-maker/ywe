import { useState } from 'react';
import { 
  CheckCircle, FileText, Smartphone, ShieldCheck, 
  Database, ShoppingBag, Terminal, DollarSign, Wallet, 
  HelpCircle, ChevronRight, Zap, RefreshCw, BarChart2,
  Lock, Code, Globe, MessageSquare, Truck
} from 'lucide-react';

export default function ProposalViewer() {
  const [activeTab, setActiveTab] = useState<'overview' | 'features' | 'calculator' | 'timeline'>('overview');
  
  // Interactive Pricing Calculator State
  const [includeSMS, setIncludeSMS] = useState(true);
  const [includePaymentGateway, setIncludePaymentGateway] = useState(true);
  const [includePremiumHosting, setIncludePremiumHosting] = useState(true);
  const [includeSEO, setIncludeSEO] = useState(false);
  const [includeInvoicePDF, setIncludeInvoicePDF] = useState(true);

  const basePrice = 35000;
  const smsPrice = 3000; // API Integration + SMS pack
  const paymentGatewayPrice = 5000; // SSLCommerz / Shurjopay setup
  const hostingPrice = 4000; // 1 year high-speed VPS + SSL + .com domain
  const seoPrice = 5000; // Comprehensive schema markup + search console setup
  const invoicePrice = 3000; // PDF order slip auto-generation

  const calculateTotalPrice = () => {
    let total = basePrice;
    if (includeSMS) total += smsPrice;
    if (includePaymentGateway) total += paymentGatewayPrice;
    if (includePremiumHosting) total += hostingPrice;
    if (includeSEO) total += seoPrice;
    if (includeInvoicePDF) total += invoicePrice;
    return total;
  };

  return (
    <div className="bg-white rounded-2xl shadow-xl border border-stone-200 overflow-hidden text-stone-800 font-sans" id="proposal-section">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-emerald-800 to-stone-900 p-8 text-white relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-700/10 rounded-full blur-3xl -mr-32 -mt-32"></div>
        <div className="relative z-10">
          <div className="inline-flex items-center gap-2 bg-emerald-700/50 text-emerald-200 text-xs px-3 py-1 rounded-full border border-emerald-500/30 mb-3">
            <ShieldCheck className="w-3.5 h-3.5" /> High-Fidelity Client Pitch Deck
          </div>
          <h2 className="text-3xl font-serif font-semibold tracking-tight">E-Commerce Development Proposal</h2>
          <p className="text-emerald-100/80 text-sm mt-2 max-w-2xl">
            Custom Premium Brand Store & Admin Panel inspired by <strong>"Believer Sign"</strong>. 
            Prepared for your client with a complete breakdown of a premium 50,000 BDT budget.
          </p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-stone-200 bg-stone-50 overflow-x-auto scrollbar-none">
        {[
          { id: 'overview', label: '1. Project Overview', icon: FileText },
          { id: 'features', label: '2. Features & Table of Contents', icon: Code },
          { id: 'calculator', label: '3. Cost Estimator', icon: DollarSign },
          { id: 'timeline', label: '4. Delivery Timeline', icon: Zap }
        ].map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-6 py-4 border-b-2 font-medium text-sm whitespace-nowrap transition-colors duration-200 ${
                activeTab === tab.id
                  ? 'border-emerald-700 text-emerald-800 bg-white'
                  : 'border-transparent text-stone-500 hover:text-stone-800 hover:bg-stone-100/50'
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Tab Contents */}
      <div className="p-8">
        
        {/* TAB 1: OVERVIEW */}
        {activeTab === 'overview' && (
          <div className="space-y-6 animate-fade-in">
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div className="space-y-4">
                <h3 className="text-xl font-serif font-bold text-stone-900 border-b border-stone-100 pb-2">The Challenge & Opportunity</h3>
                <p className="text-stone-600 text-sm leading-relaxed">
                  Brands like <strong>Believer Sign</strong> have proven that there is massive demand in Bangladesh for high-quality, minimalistic Islamic apparel and spiritual lifestyle products. Customers demand a shopping experience that feels holy, premium, and trustworthy.
                </p>
                <p className="text-stone-600 text-sm leading-relaxed">
                  A <strong>50,000 BDT budget</strong> allows us to bypass slow, generic WordPress themes and build a custom, ultra-fast <strong>React + Next.js</strong> or optimized <strong>Node.js</strong> web application that loads instantly under any mobile network in Bangladesh, boasting a 100% purchase conversion rate.
                </p>
                <div className="bg-emerald-50 rounded-xl p-4 border border-emerald-100 flex items-start gap-3">
                  <div className="p-2 bg-emerald-600 text-white rounded-lg mt-0.5">
                    <CheckCircle className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-emerald-900 text-sm">Standard of Excellence</h4>
                    <p className="text-emerald-800/80 text-xs mt-0.5">
                      Fully production-ready code with responsive layout, real-time admin metrics, and zero templates. Clean database schemas and fast page loading (A-grade Lighthouse score).
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-stone-50 rounded-2xl p-6 border border-stone-100 space-y-4">
                <h4 className="font-semibold text-stone-900 text-sm tracking-wide uppercase">Core Package Pillars</h4>
                <div className="space-y-3">
                  {[
                    { title: 'Custom Premium Branding', desc: 'Islamic minimalist aesthetic, custom typography, animations.', icon: Globe },
                    { title: 'Payment Gateways BD', desc: 'Integrated with bKash, Nagad, Visa, Mastercard via SSLCommerz.', icon: Wallet },
                    { title: 'WhatsApp Instant Sync', desc: 'Redirects order slips directly to the sales agent on WhatsApp.', icon: MessageSquare },
                    { title: 'Admin Command Panel', desc: 'Secure panel to process orders, track inventory, and view analytics.', icon: BarChart2 },
                    { title: 'SMS Transaction API', desc: 'Send automated order confirm messages to customers\' phones.', icon: Smartphone },
                    { title: 'High-Performance Hosting', desc: 'SSL certificate, custom domain, CDN cache, and hourly backups.', icon: Lock }
                  ].map((pillar, idx) => {
                    const Icon = pillar.icon;
                    return (
                      <div key={idx} className="flex gap-3">
                        <div className="mt-0.5 text-emerald-700">
                          <Icon className="w-4 h-4" />
                        </div>
                        <div>
                          <h5 className="font-semibold text-xs text-stone-800">{pillar.title}</h5>
                          <p className="text-[11px] text-stone-500">{pillar.desc}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: FEATURES & TABLE OF CONTENTS */}
        {activeTab === 'features' && (
          <div className="space-y-6 animate-fade-in">
            <h3 className="text-xl font-serif font-bold text-stone-900 border-b border-stone-100 pb-2">Website Technical Table of Contents</h3>
            
            <p className="text-xs text-stone-500">
              Below is the comprehensive architectural table of contents and features that we will deliver within the 50,000 BDT budget limit.
            </p>

            <div className="grid md:grid-cols-2 gap-6">
              {[
                {
                  title: 'Module 1: High-Conversion Front Store',
                  items: [
                    'Minimalist Landing Page with dynamic promotional sliders',
                    'Interactive categories (Panjabi, T-Shirts, Hoodies, Wall Art, Attar)',
                    'Intelligent Search with instant filter suggestion & color/size tags',
                    'Responsive mobile shopping cart with sticky floating bottom bar',
                    'Beautiful animation states (add to cart ripple, staggered load)'
                  ],
                  color: 'border-l-4 border-l-emerald-600'
                },
                {
                  title: 'Module 2: BD Localization & Fast Checkout',
                  items: [
                    'Single-page dynamic Checkout (bypasses redundant registration screens)',
                    'Automated shipping calculation (Dhaka City: ৳80 | Outside Dhaka: ৳150)',
                    'bKash / Nagad / Rocket transaction ID fields with error handling',
                    'WhatsApp Order Slip Generator - routes formatted text directly to admin',
                    'Real-time order success page with unique order-tracking ID'
                  ],
                  color: 'border-l-4 border-l-amber-600'
                },
                {
                  title: 'Module 3: Secure Back Office Admin Portal',
                  items: [
                    'Dynamic product manager (add, delete, adjust stock, pricing, and discount)',
                    'Live Order Tracker (Pending, Processing, Shipped, Delivered, Cancelled)',
                    'Visual Analytics Dashboard showing daily sales, orders count, and revenue',
                    'Customer Database with contact list, order history, and VIP ranking',
                    'PDF Invoice Generator for quick shipping label printing'
                  ],
                  color: 'border-l-4 border-l-stone-800'
                },
                {
                  title: 'Module 4: Enterprise Infrastructure & Integrations',
                  items: [
                    'SSLCommerz or Shurjopay Merchant sandbox & production accounts API setup',
                    'Greenweb SMS Gateway / BulkSMSBD API integration for OTP & Alerts',
                    'SEO schema markup optimization & automated sitemap submission',
                    'High-speed VPS (DigitalOcean / Hetzner) deployment with Node.js',
                    'Daily backup engine + Cloudflare DDoS Shield'
                  ],
                  color: 'border-l-4 border-l-blue-600'
                }
              ].map((module, mIdx) => (
                <div key={mIdx} className={`p-5 bg-stone-50 rounded-xl border border-stone-100 ${module.color}`}>
                  <h4 className="font-semibold text-stone-900 text-sm mb-3 flex items-center gap-1.5">
                    <span className="w-5 h-5 rounded-full bg-stone-200 text-stone-800 text-[10px] inline-flex items-center justify-center font-bold">{mIdx + 1}</span>
                    {module.title}
                  </h4>
                  <ul className="space-y-2">
                    {module.items.map((item, iIdx) => (
                      <li key={iIdx} className="text-xs text-stone-600 flex items-start gap-2">
                        <CheckCircle className="w-3.5 h-3.5 text-emerald-600 mt-0.5 shrink-0" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 3: COST ESTIMATOR */}
        {activeTab === 'calculator' && (
          <div className="space-y-6 animate-fade-in">
            <div className="grid md:grid-cols-2 gap-8">
              <div className="space-y-4">
                <h3 className="text-xl font-serif font-bold text-stone-900 border-b border-stone-100 pb-2">Custom Scope & Cost Builder</h3>
                <p className="text-xs text-stone-500">
                  Select the modules you wish to include in the delivery contract. The cost will automatically compute to ensure transparency. Perfect to show the client on your phone or tablet!
                </p>

                <div className="space-y-3">
                  {/* Basic Package Info */}
                  <div className="flex justify-between items-center p-3 bg-stone-100 rounded-xl border border-stone-200">
                    <div>
                      <span className="font-semibold text-xs text-stone-800 block">Base Core Platform</span>
                      <span className="text-[10px] text-stone-500">Responsive catalog, local checkout, state management</span>
                    </div>
                    <span className="font-semibold text-xs text-stone-700">৳{basePrice.toLocaleString()}</span>
                  </div>

                  {/* SMS Gateways */}
                  <label className="flex items-center justify-between p-3 rounded-xl border border-stone-200 hover:bg-stone-50 cursor-pointer transition-colors">
                    <div className="flex items-center gap-3">
                      <input 
                        type="checkbox" 
                        checked={includeSMS} 
                        onChange={(e) => setIncludeSMS(e.target.checked)}
                        className="w-4 h-4 accent-emerald-700 rounded"
                      />
                      <div>
                        <span className="font-semibold text-xs text-stone-800 block">SMS Gateway API Integration</span>
                        <span className="text-[10px] text-stone-500">Greenweb API + 2000 SMS pack for client alerts</span>
                      </div>
                    </div>
                    <span className="font-semibold text-xs text-stone-700">৳{smsPrice.toLocaleString()}</span>
                  </label>

                  {/* Payment Gateways */}
                  <label className="flex items-center justify-between p-3 rounded-xl border border-stone-200 hover:bg-stone-50 cursor-pointer transition-colors">
                    <div className="flex items-center gap-3">
                      <input 
                        type="checkbox" 
                        checked={includePaymentGateway} 
                        onChange={(e) => setIncludePaymentGateway(e.target.checked)}
                        className="w-4 h-4 accent-emerald-700 rounded"
                      />
                      <div>
                        <span className="font-semibold text-xs text-stone-800 block">SSLCommerz / Shurjopay Setup</span>
                        <span className="text-[10px] text-stone-500">Direct online payment via cards & instant mobile wallets</span>
                      </div>
                    </div>
                    <span className="font-semibold text-xs text-stone-700">৳{paymentGatewayPrice.toLocaleString()}</span>
                  </label>

                  {/* Premium VPS Hosting */}
                  <label className="flex items-center justify-between p-3 rounded-xl border border-stone-200 hover:bg-stone-50 cursor-pointer transition-colors">
                    <div className="flex items-center gap-3">
                      <input 
                        type="checkbox" 
                        checked={includePremiumHosting} 
                        onChange={(e) => setIncludePremiumHosting(e.target.checked)}
                        className="w-4 h-4 accent-emerald-700 rounded"
                      />
                      <div>
                        <span className="font-semibold text-xs text-stone-800 block">Premium VPS Hosting (1 Year)</span>
                        <span className="text-[10px] text-stone-500">High-speed server, SSL certificate, .com custom domain</span>
                      </div>
                    </div>
                    <span className="font-semibold text-xs text-stone-700">৳{hostingPrice.toLocaleString()}</span>
                  </label>

                  {/* Invoice PDF generator */}
                  <label className="flex items-center justify-between p-3 rounded-xl border border-stone-200 hover:bg-stone-50 cursor-pointer transition-colors">
                    <div className="flex items-center gap-3">
                      <input 
                        type="checkbox" 
                        checked={includeInvoicePDF} 
                        onChange={(e) => setIncludeInvoicePDF(e.target.checked)}
                        className="w-4 h-4 accent-emerald-700 rounded"
                      />
                      <div>
                        <span className="font-semibold text-xs text-stone-800 block">Automated PDF Invoices</span>
                        <span className="text-[10px] text-stone-500">Generate clean invoice slips for orders automatically</span>
                      </div>
                    </div>
                    <span className="font-semibold text-xs text-stone-700">৳{invoicePrice.toLocaleString()}</span>
                  </label>

                  {/* SEO Optimizations */}
                  <label className="flex items-center justify-between p-3 rounded-xl border border-stone-200 hover:bg-stone-50 cursor-pointer transition-colors">
                    <div className="flex items-center gap-3">
                      <input 
                        type="checkbox" 
                        checked={includeSEO} 
                        onChange={(e) => setIncludeSEO(e.target.checked)}
                        className="w-4 h-4 accent-emerald-700 rounded"
                      />
                      <div>
                        <span className="font-semibold text-xs text-stone-800 block">Google SEO schema markup</span>
                        <span className="text-[10px] text-stone-500">Index on Google for keywords like "Islamic apparel"</span>
                      </div>
                    </div>
                    <span className="font-semibold text-xs text-stone-700">৳{seoPrice.toLocaleString()}</span>
                  </label>
                </div>
              </div>

              {/* Total Calculation Display Card */}
              <div className="bg-emerald-50 rounded-2xl p-8 border border-emerald-100 flex flex-col justify-between space-y-6">
                <div className="space-y-4">
                  <span className="text-xs uppercase tracking-wider text-emerald-800 font-semibold">Total Scope Value</span>
                  <div className="flex items-baseline gap-1">
                    <span className="text-4xl font-serif font-black text-emerald-900">৳{calculateTotalPrice().toLocaleString()}</span>
                    <span className="text-xs text-emerald-700 font-semibold">BDT</span>
                  </div>
                  <div className="border-t border-emerald-200/50 pt-4 space-y-2">
                    <div className="flex justify-between text-xs text-emerald-800">
                      <span>Development & Coding:</span>
                      <span className="font-medium">৳35,000</span>
                    </div>
                    <div className="flex justify-between text-xs text-emerald-800">
                      <span>Selected Add-ons:</span>
                      <span className="font-medium">৳{(calculateTotalPrice() - basePrice).toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-xs text-emerald-900 font-bold border-t border-emerald-200/50 pt-2">
                      <span>Final Net Quote:</span>
                      <span>৳{calculateTotalPrice().toLocaleString()}</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="text-[11px] text-emerald-800/80 leading-relaxed bg-emerald-600/5 p-3 rounded-lg border border-emerald-600/10">
                    💡 <strong>Pro Tip for 50k TK Budget:</strong> This selection is fully optimized to fit a 50k contract perfectly. It covers high-speed VPS hosting, SSL security, the bKash checkout portal, automated PDF invoices, and Greenweb SMS reminders, delivering a top-tier premium website that matches any major lifestyle brand in Bangladesh.
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: TIMELINE */}
        {activeTab === 'timeline' && (
          <div className="space-y-6 animate-fade-in">
            <h3 className="text-xl font-serif font-bold text-stone-900 border-b border-stone-100 pb-2">Agile Delivery Timeline (4 Weeks)</h3>
            
            <p className="text-xs text-stone-500">
              A precise, step-by-step implementation guide representing how a professional agency or senior freelancer manages the project lifecycle.
            </p>

            <div className="relative border-l border-stone-200 ml-3 pl-6 space-y-6">
              {[
                {
                  week: 'Week 1',
                  title: 'Brand Assets, UX Design & Wireframing',
                  desc: 'Acquisition of brand guidelines, typography selection, custom vector logo design, and high-fidelity screen mockup wireframes on Figma for client sign-off.'
                },
                {
                  week: 'Week 2',
                  title: 'Frontend Component Architecture & Styling',
                  desc: 'Converting Figma mockups to pixel-perfect React + Tailwind responsive code. Implementing shopping bags, category filters, interactive drawers, and page transitions.'
                },
                {
                  week: 'Week 3',
                  title: 'Database Setup, Admin Panel & API Integration',
                  desc: 'Creating the Node.js backend. Integrating bKash/Nagad checkout logic, establishing the Firestore or Postgres database schema, and setting up the live admin management panel.'
                },
                {
                  week: 'Week 4',
                  title: 'SMS Gateway, Domain, Host Setup & Live Testing',
                  desc: 'Integrating the Greenweb SMS API for OTP and alerts, linking custom domain to VPS, implementing SSL certificate, full end-to-end beta checkout tests, and final delivery hand-off.'
                }
              ].map((step, idx) => (
                <div key={idx} className="relative">
                  {/* Dot indicator */}
                  <span className="absolute -left-[31px] top-1 w-2.5 h-2.5 rounded-full bg-emerald-600 ring-4 ring-white"></span>
                  <div>
                    <span className="inline-block bg-stone-100 text-stone-800 text-[10px] font-bold px-2 py-0.5 rounded mb-1">{step.week}</span>
                    <h4 className="font-semibold text-stone-900 text-sm">{step.title}</h4>
                    <p className="text-xs text-stone-600 mt-1 leading-relaxed">{step.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
